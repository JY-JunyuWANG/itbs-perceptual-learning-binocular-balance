% Define the input folder and output file names
input_folder = '';
output_file = 'Motion_SNR_Threshold_Ratio.xlsx';

% Find the .mat files in the input folder
mat_files = dir(fullfile(input_folder, '*.mat'));

% Initialize a cell array to store data for Excel export
excel_data = cell(1, 15); % 15 columns to include Protocol

% Initialize a map to store Criteria for NAME, TIME, and Order
criteria_map = containers.Map('KeyType', 'char', 'ValueType', 'any');

% Initialize a temporary array to store data for later processing
temp_data = {}; % Initialize as an empty cell array

% Loop over the .mat files and extract the data
for i = 1:numel(mat_files)
    % Load the data from the current .mat file
    mat_file = fullfile(mat_files(i).folder, mat_files(i).name);
    load(mat_file, 'Data');
    
    % Ensure Data exists and has the required field
    if ~isfield(Data, 'Threshold') || isempty(Data.Threshold)
        warning('Threshold data not found in %s', mat_file);
        continue; % Skip to the next file
    end
    
    % Extract the first two rows of each column
    thresholds = Data.Threshold(1:2, :);
    
    % Calculate the SNR ratio based on the comparison of thresholds
    snr_ratio = abs(thresholds(1, :) - thresholds(2, :)) ./ (thresholds(1, :) + thresholds(2, :));
    snr_ratio(isnan(snr_ratio)) = 0; % Handle the case where both thresholds are zero

    % Extract the file name from the input file name
    [~, filename, ~] = fileparts(mat_file);
    
    % Calculate additional fields using string indexing
    name = filename(); 
    time = "D1"; 
    order = filename(); 
    protocol = filename(); 
    
    % Calculate Criteria based on Thresholds
    criteria = '';
    if thresholds(1, 1) < thresholds(2, 1)
        criteria = 'R';  % Right
    else
        criteria = 'L';  % Left
    end
    
    % Initialize Criteria Base
    criteria_base = '';

    % Logic for storing Criteria in the map
    key = sprintf('%s_%s_%s', name, time, order);
    if strcmp(time, 'D1') && startsWith(order, 'E') % Check if TIME is D1 and Order starts with 'E'
        criteria_map(key) = criteria; % Store Criteria in map
    end
    
    % Check if NAME is already in the map to fill Criteria_Base
    base_key_e1 = sprintf('%s_%s_%s', name, 'D1', 'E1');
    base_key_e2 = sprintf('%s_%s_%s', name, 'D1', 'E2');

    if isKey(criteria_map, base_key_e1) && isKey(criteria_map, base_key_e2)
        criteria_e1 = criteria_map(base_key_e1);
        criteria_e2 = criteria_map(base_key_e2);
        
        if strcmp(criteria_e1, criteria_e2) % If criteria are the same
            criteria_base = criteria_e1; % Use the common criteria
        else
            % If criteria are different, store temporary results for later
            temp_data{end+1} = struct('name', name, 'thresholds', thresholds, ...
                                       'order', order, 'snr_ratio', snr_ratio);
        end
    elseif isKey(criteria_map, base_key_e1)
        criteria_base = criteria_map(base_key_e1); % Only E1 exists
    elseif isKey(criteria_map, base_key_e2)
        criteria_base = criteria_map(base_key_e2); % Only E2 exists
    end
    
    % Calculate Final Ratio
    final_ratio = snr_ratio(1); % Default to SNR_Ratio
    if strcmp(criteria, criteria_base)
        final_ratio = snr_ratio(1);
    else
        final_ratio = -snr_ratio(1);
    end
    
    % Construct the row data for the output file
    row_data = {filename, thresholds(1, 1), thresholds(2, 1), snr_ratio(1), ...
                name, time, order, criteria, criteria_base, ...
                final_ratio, NaN, NaN, NaN, NaN, protocol}; % Placeholder for means and Protocol
    
    % Append data to the cell array for Excel export
    excel_data(end+1, :) = row_data; % Append row_data as a new row
end

% Create a table from the cell array
dataTable = cell2table(excel_data(2:end, :), 'VariableNames', {'Filename', 'Threshold1', 'Threshold2', ...
    'SNR_Ratio', 'NAME', 'TIME', 'Order', 'Criteria', ...
    'Criteria_Base', 'Final_Ratio', 'Threshold1_Mean', 'Threshold2_Mean', 'Ratio_Mean', 'Criteria_Mean', 'Protocol'});

% Process stored temporary results to update Criteria_Base based on new means
for i = 1:length(temp_data)
    e1_row = dataTable(strcmp(dataTable.NAME, temp_data{i}.name) & ...
                       strcmp(dataTable.TIME, 'D1') & ...
                       strcmp(dataTable.Order, 'E1'), :);
    e2_row = dataTable(strcmp(dataTable.NAME, temp_data{i}.name) & ...
                       strcmp(dataTable.TIME, 'D1') & ...
                       strcmp(dataTable.Order, 'E2'), :);
    
    if ~isempty(e1_row) && ~isempty(e2_row)
        % Calculate new means
        threshold1_mean = mean([e1_row.Threshold1, e2_row.Threshold1]);
        threshold2_mean = mean([e1_row.Threshold2, e2_row.Threshold2]);
        
        % Compare means to set Criteria_Base
        if threshold1_mean > threshold2_mean
            criteria_base = 'L'; % Left
        elseif threshold1_mean < threshold2_mean
            criteria_base = 'R'; % Right
        else
            criteria_base = ''; % Handle case where they are equal
        end
        
        % Update dataTable with the new Criteria_Base for all matching NAME
        dataTable.Criteria_Base(strcmp(dataTable.NAME, temp_data{i}.name)) = {criteria_base};
    end
end

% Fill in Threshold Means for E1 and E2
for i = 1:height(dataTable)
    current_name = dataTable.NAME{i};
    current_time = dataTable.TIME{i};
    
    % Process for E1 and E2
    e1_row = dataTable(strcmp(dataTable.NAME, current_name) & ...
                       strcmp(dataTable.TIME, current_time) & ...
                       strcmp(dataTable.Order, 'E1'), :);
    e2_row = dataTable(strcmp(dataTable.NAME, current_name) & ...
                       strcmp(dataTable.TIME, current_time) & ...
                       strcmp(dataTable.Order, 'E2'), :);
    
    if ~isempty(e1_row) && ~isempty(e2_row)
        if strcmp(e1_row.Criteria{1}, e2_row.Criteria{1}) % Criteria ??
            %Ratio_Mean
            ratio_mean = mean([e1_row.Final_Ratio, e2_row.Final_Ratio]);
            dataTable.Ratio_Mean(strcmp(dataTable.NAME, current_name) & ...
                                  strcmp(dataTable.TIME, current_time) & ...
                                  strcmp(dataTable.Order, 'E1')) = ratio_mean;
        else %Criteria
            threshold1_mean = mean([e1_row.Threshold1, e2_row.Threshold1]);
            threshold2_mean = mean([e1_row.Threshold2, e2_row.Threshold2]);
            
            %Threshold1_Mean & Threshold2_Mean
            dataTable.Threshold1_Mean(strcmp(dataTable.NAME, current_name) & ...
                                       strcmp(dataTable.TIME, current_time) & ...
                                       strcmp(dataTable.Order, 'E1')) = threshold1_mean;
            dataTable.Threshold2_Mean(strcmp(dataTable.NAME, current_name) & ...
                                       strcmp(dataTable.TIME, current_time) & ...
                                       strcmp(dataTable.Order, 'E1')) = threshold2_mean;

            %Ratio_Mean
            if threshold1_mean > threshold2_mean
                ratio_mean = (threshold1_mean - threshold2_mean) / (threshold1_mean + threshold2_mean);
            else
                ratio_mean = (threshold2_mean - threshold1_mean) / (threshold1_mean + threshold2_mean);
            end
            
            %Ratio_Mean
            dataTable.Ratio_Mean(strcmp(dataTable.NAME, current_name) & ...
                                  strcmp(dataTable.TIME, current_time) & ...
                                  strcmp(dataTable.Order, 'E1')) = ratio_mean;
        end
    end
end

%O1 & O2
for i = 1:height(dataTable)
    current_name = dataTable.NAME{i};
    current_time = dataTable.TIME{i};
    
    % Process for O1 and O2
    o1_row = dataTable(strcmp(dataTable.NAME, current_name) & ...
                       strcmp(dataTable.TIME, current_time) & ...
                       strcmp(dataTable.Order, 'O1'), :);
    o2_row = dataTable(strcmp(dataTable.NAME, current_name) & ...
                       strcmp(dataTable.TIME, current_time) & ...
                       strcmp(dataTable.Order, 'O2'), :);
    
    if ~isempty(o1_row) && ~isempty(o2_row)
        if strcmp(o1_row.Criteria{1}, o2_row.Criteria{1}) % Criteria ??
            % ?? Ratio_Mean
            ratio_mean = mean([o1_row.Final_Ratio, o2_row.Final_Ratio]);
            dataTable.Ratio_Mean(strcmp(dataTable.NAME, current_name) & ...
                                  strcmp(dataTable.TIME, current_time) & ...
                                  strcmp(dataTable.Order, 'O1')) = ratio_mean;
        else % Criteria
            threshold1_mean = mean([o1_row.Threshold1, o2_row.Threshold1]);
            threshold2_mean = mean([o1_row.Threshold2, o2_row.Threshold2]);
            
            % Threshold1_Mean & Threshold2_Mean
            dataTable.Threshold1_Mean(strcmp(dataTable.NAME, current_name) & ...
                                       strcmp(dataTable.TIME, current_time) & ...
                                       strcmp(dataTable.Order, 'O1')) = threshold1_mean;
            dataTable.Threshold2_Mean(strcmp(dataTable.NAME, current_name) & ...
                                       strcmp(dataTable.TIME, current_time) & ...
                                       strcmp(dataTable.Order, 'O1')) = threshold2_mean;

            %Ratio_Mean
            if threshold1_mean > threshold2_mean
                ratio_mean = (threshold1_mean - threshold2_mean) / (threshold1_mean + threshold2_mean);
            else
                ratio_mean = (threshold2_mean - threshold1_mean) / (threshold1_mean + threshold2_mean);
            end
            
            %Ratio_Mean
            dataTable.Ratio_Mean(strcmp(dataTable.NAME, current_name) & ...
                                  strcmp(dataTable.TIME, current_time) & ...
                                  strcmp(dataTable.Order, 'O1')) = ratio_mean;
        end
    end
end

% ?? Criteria_Mean
criteria_mean = cell(height(dataTable), 1);
for i = 1:height(dataTable)
    threshold1_mean = dataTable.Threshold1_Mean(i);
    threshold2_mean = dataTable.Threshold2_Mean(i);
    
    if ~isnan(threshold1_mean) && ~isnan(threshold2_mean)
        if threshold1_mean > threshold2_mean
            criteria_mean{i} = 'L';
        elseif threshold1_mean < threshold2_mean
            criteria_mean{i} = 'R';
        else
            criteria_mean{i} = ''; % Handle case where they are equal (optional)
        end
    else
        criteria_mean{i} = ''; % Handle empty cases
    end
end

% Add Criteria_Mean to the table
dataTable.Criteria_Mean = criteria_mean;

% Compare Criteria_Base and Criteria_Mean for consistency
for i = 1:height(dataTable)
    if ~isempty(dataTable.Criteria_Mean{i}) && ~isempty(dataTable.Criteria_Base{i})
        if ~strcmp(dataTable.Criteria_Mean{i}, dataTable.Criteria_Base{i})
            dataTable.Ratio_Mean(i) = -dataTable.Ratio_Mean(i); % Make Ratio_Mean negative if not consistent
        end
    end
end


for i = 1:height(dataTable)
    current_name = dataTable.NAME{i};
    current_criteria = dataTable.Criteria{i};
    current_criteria_base = dataTable.Criteria_Base{i};
    
    if isempty(current_criteria_base)
        %Criteria_Base_NAME_TIME=D1_Order=E1
        e1_row = dataTable(strcmp(dataTable.NAME, current_name) & ...
                           strcmp(dataTable.TIME, 'D1') & ...
                           strcmp(dataTable.Order, 'E1'), :);
        if ~isempty(e1_row)
            current_criteria_base = e1_row.Criteria_Base{1};
            dataTable.Criteria_Base{i} = current_criteria_base;
        end
    end
    
    %Criteria
    if ~isempty(current_criteria_base) && ~isempty(current_criteria)
        if strcmp(current_criteria, current_criteria_base)
            % Criteria_Base
            dataTable.Final_Ratio(i) = abs(dataTable.Final_Ratio(i));
        else
            % Criteria_Base
            dataTable.Final_Ratio(i) = -abs(dataTable.Final_Ratio(i));
        end
    else
        %Final_Ratio
        continue;
    end
end

% Save the table to the Excel file
writetable(dataTable, output_file);

%Ratio_Mean
for i = 1:height(dataTable)
    if ~isnan(dataTable.Ratio_Mean(i))
        % Ratio_Mean
        dataTable.Ratio_Mean(i) = abs(dataTable.Ratio_Mean(i));
    end
end

% Criteria_Mean
for i = 1:height(dataTable)
    if isempty(dataTable.Criteria_Mean{i}) % ??Criteria_Mean??
        if ~isnan(dataTable.Ratio_Mean(i)) % ??Ratio_Mean???
            % Ratio_Mean
            dataTable.Ratio_Mean(i) = sign(dataTable.Final_Ratio(i)) * abs(dataTable.Ratio_Mean(i));
        end
    else % Criteria_Mean
        if ~isempty(dataTable.Criteria_Base{i}) % ??Criteria_Base????
            % Criteria_Base
            if strcmp(dataTable.Criteria_Mean{i}, dataTable.Criteria_Base{i})
                %Ratio_Mean
                dataTable.Ratio_Mean(i) = abs(dataTable.Ratio_Mean(i));
            else
                % Ratio_Mean
                dataTable.Ratio_Mean(i) = -abs(dataTable.Ratio_Mean(i));
            end
        end
    end
end

% Excel
writetable(dataTable, output_file);