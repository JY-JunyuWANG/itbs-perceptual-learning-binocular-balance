function [samplehorizcolor1, samplehorizcolor2, samplevertcolor1, samplevertcolor2, blankouthoriz, blankoutvert] = ComputeBackgroundColors(display)

%runs only once -- keeps background grid the same for the entire block

sqsize =1.50; %degrees
sqsizepx = angle2pix(display, sqsize);

%number of sq that will fit horizontally
nmsqhoriz = floor(display.resolution(1)/(sqsizepx*2));
totalarea = nmsqhoriz*sqsizepx*2;
gapLR = (display.resolution(1) - totalarea)/2;


%number of sq that will fit vertically
nmsqvert = floor(display.resolution(2)/(sqsizepx*2));
totalarea2 = nmsqvert*sqsizepx*2;
gapUD = (display.resolution(2) - totalarea2)/2;


totalhorizsq = nmsqhoriz*6; %all rows
totalvertsq = nmsqvert*6; %all columns

samplehorizcolor1 = randsample(totalhorizsq, totalhorizsq/2);
samplehorizcolor2 = [];
for k = 1:totalhorizsq
    if any(samplehorizcolor1==k)
    else
        samplehorizcolor2 = [samplehorizcolor2 k];
    end
end


samplevertcolor1 = randsample(totalvertsq, totalvertsq/2);
samplevertcolor2 = [];
for k = 1:totalvertsq
    if any(samplevertcolor1==k)
    else
        samplevertcolor2 = [samplevertcolor2 k];
    end
end


%% select portion to grey out

%horizontal
blankouthoriz = [];
addset = 0;
for k = 1:6 %number of rows/columns
    
    totalblankforhoriz = round(0.05*nmsqhoriz); %total to blankout for each row
    blankout = randsample(nmsqhoriz, totalblankforhoriz);
    blankout = blankout+addset; %because x, y positions are given in one long matrix, this adds the equivalent of a row/column;
    blankouthoriz = [blankouthoriz; blankout];
    addset = addset+nmsqhoriz;
end
    
    
%vertical
blankoutvert = [];
addset = 0;
for k = 1:6 %number of rows/columns
    
    totalblankforvert = round(0.05*nmsqvert); %total to blankout for each row
    blankout = randsample(nmsqvert, totalblankforvert);
    blankout = blankout+addset; %because x, y positions are given in one long matrix, this adds the equivalent of a row/column;
    blankoutvert = [blankoutvert; blankout];
    addset = addset+nmsqvert;
end
    
    