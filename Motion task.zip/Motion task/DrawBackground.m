%% Draw background grid

function DrawBackground(display, samplehorizcolor1, samplehorizcolor2, samplevertcolor1, samplevertcolor2, blankouthoriz, blankoutvert);

sqsize = 1.50; %degrees
sqsizepx = angle2pix(display, sqsize);

%we want three columns down the left and right and three rows across the
%bottom and top.  Each grid column/row will be separated by a blank
%column/row of equal width.

sqcolor1 = [255 255 255];
sqcolor2 = [0 0 0];
sqcolor3 = [128 128 128]; %blank out 95% of the sq.

sqcolor1 = [255 255 255];
sqcolor2 = [0 0 0];
sqcolor3 = [128 128 128]; %blank out 95% of the sq.

%number of sq that will fit horizontally
nmsqhoriz = floor(display.resolution(1)/(sqsizepx*2));
totalarea = nmsqhoriz*sqsizepx*2;
gapLR = (display.resolution(1) - totalarea)/2;


%number of sq that will fit vertically
nmsqvert = floor(display.resolution(2)/(sqsizepx*2));
totalarea2 = nmsqvert*sqsizepx*2;
gapUD = (display.resolution(2) - totalarea2)/2;

%% Horizontal
%deal with horizontal first row
curbuff = gapLR;
for j = 1:nmsqhoriz
    sqpos_x(j) = curbuff + sqsizepx;
    sqpos_y(j) = gapUD+sqsizepx;
    curbuff = curbuff+sqsizepx*2;
end

%deal with horizontal secondrow
curbuff = gapLR;
for j = (length(sqpos_x)+1):(nmsqhoriz*2)
    sqpos_x(j) = curbuff + sqsizepx;
    sqpos_y(j) = gapUD+sqsizepx+sqsizepx*2;
    curbuff = curbuff+sqsizepx*2;
end


%deal with horizontal third row
curbuff = gapLR;
for j = (length(sqpos_x)+1):(nmsqhoriz*3)
    sqpos_x(j) = curbuff + sqsizepx;
    sqpos_y(j) = gapUD+sqsizepx+sqsizepx*2+sqsizepx*2;
    curbuff = curbuff+sqsizepx*2;
end


%deal with horizontal fourth row (first from the bottom)
curbuff = gapLR;
for j = (length(sqpos_x)+1):(nmsqhoriz*4)
    sqpos_x(j) = curbuff + sqsizepx;
    sqpos_y(j) = display.resolution(2) - gapUD-sqsizepx;
    curbuff = curbuff+sqsizepx*2;
end


%deal with horizontal fifth row (second from the bottom)
curbuff = gapLR;
for j = (length(sqpos_x)+1):(nmsqhoriz*5)
    sqpos_x(j) = curbuff + sqsizepx;
    sqpos_y(j) = display.resolution(2) - gapUD-sqsizepx - sqsizepx*2;
    curbuff = curbuff+sqsizepx*2;
end


%deal with horizontal sixth row (third from the bottom)
curbuff = gapLR;
for j = (length(sqpos_x)+1):(nmsqhoriz*6)
    sqpos_x(j) = curbuff + sqsizepx;
    sqpos_y(j) = display.resolution(2) - gapUD-sqsizepx - sqsizepx*2 - sqsizepx*2;
    curbuff = curbuff+sqsizepx*2;
end



Screen('SelectStereoDrawBuffer',display.windowPtr, 1);
Screen('DrawDots',display.windowPtr,[sqpos_x(samplehorizcolor1); sqpos_y(samplehorizcolor1)], sqsizepx, sqcolor1,[0,0],0);
Screen('DrawDots',display.windowPtr,[sqpos_x(samplehorizcolor2); sqpos_y(samplehorizcolor2)], sqsizepx, sqcolor2,[0,0],0);

Screen('DrawDots',display.windowPtr,[sqpos_x(blankouthoriz); sqpos_y(blankouthoriz)], sqsizepx, sqcolor3,[0,0],0);

Screen('SelectStereoDrawBuffer',display.windowPtr, 0);
Screen('DrawDots',display.windowPtr,[sqpos_x(samplehorizcolor1); sqpos_y(samplehorizcolor1)], sqsizepx, sqcolor1,[0,0],0);
Screen('DrawDots',display.windowPtr,[sqpos_x(samplehorizcolor2); sqpos_y(samplehorizcolor2)], sqsizepx, sqcolor2,[0,0],0);

Screen('DrawDots',display.windowPtr,[sqpos_x(blankouthoriz); sqpos_y(blankouthoriz)], sqsizepx, sqcolor3,[0,0],0);
%% Vertical
%deal with vertical first row 

clear sqpos_x;
clear sqpos_y;

curbuff = gapUD;
for j = 1:nmsqvert
    sqpos_x(j) = gapLR+sqsizepx;
    sqpos_y(j) = curbuff + sqsizepx;
    curbuff = curbuff+sqsizepx*2;
end


%deal with vertical second row 

curbuff = gapUD;
for j = (length(sqpos_x)+1):(nmsqvert*2)
    sqpos_x(j) = gapLR+sqsizepx+sqsizepx*2;
    sqpos_y(j) = curbuff + sqsizepx;
    curbuff = curbuff+sqsizepx*2;
end

%deal with vertical third row 

curbuff = gapUD;
for j = (length(sqpos_x)+1):(nmsqvert*3)
    sqpos_x(j) = gapLR+sqsizepx+sqsizepx*2+sqsizepx*2;
    sqpos_y(j) = curbuff + sqsizepx;
    curbuff = curbuff+sqsizepx*2;
end


%deal with vertical fourth row (1st from the left) 

curbuff = gapUD;
for j = (length(sqpos_x)+1):(nmsqvert*4)
    sqpos_x(j) = display.resolution(1) - gapLR - sqsizepx;
    sqpos_y(j) = curbuff + sqsizepx;
    curbuff = curbuff+sqsizepx*2;
end


%deal with vertical fifth row (2nd from the left) 

curbuff = gapUD;
for j = (length(sqpos_x)+1):(nmsqvert*5)
    sqpos_x(j) = display.resolution(1) - gapLR - sqsizepx - sqsizepx*2;
    sqpos_y(j) = curbuff + sqsizepx;
    curbuff = curbuff+sqsizepx*2;
end

%deal with vertical sixth row (3rd from the left) 

curbuff = gapUD;
for j = (length(sqpos_x)+1):(nmsqvert*6)
    sqpos_x(j) = display.resolution(1) - gapLR - sqsizepx - sqsizepx*2 - sqsizepx*2;
    sqpos_y(j) = curbuff + sqsizepx;
    curbuff = curbuff+sqsizepx*2;
end

Screen('SelectStereoDrawBuffer',display.windowPtr, 1);
Screen('DrawDots',display.windowPtr,[sqpos_x(samplevertcolor1); sqpos_y(samplevertcolor1)], sqsizepx, sqcolor1,[0,0],0);
Screen('DrawDots',display.windowPtr,[sqpos_x(samplevertcolor2); sqpos_y(samplevertcolor2)], sqsizepx, sqcolor2,[0,0],0);

Screen('DrawDots',display.windowPtr,[sqpos_x(blankoutvert); sqpos_y(blankoutvert)], sqsizepx, sqcolor3,[0,0],0);

Screen('SelectStereoDrawBuffer',display.windowPtr, 0);
Screen('DrawDots',display.windowPtr,[sqpos_x(samplevertcolor1); sqpos_y(samplevertcolor1)], sqsizepx, sqcolor1,[0,0],0);
Screen('DrawDots',display.windowPtr,[sqpos_x(samplevertcolor2); sqpos_y(samplevertcolor2)], sqsizepx, sqcolor2,[0,0],0);

Screen('DrawDots',display.windowPtr,[sqpos_x(blankoutvert); sqpos_y(blankoutvert)], sqsizepx, sqcolor3,[0,0],0);
