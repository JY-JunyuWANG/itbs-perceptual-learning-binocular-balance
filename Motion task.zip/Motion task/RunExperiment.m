%Open windows and run experiment

function RunExperiment(subjectID, trials, prtrials, nconditions, scrnvbl, viewdist, conditions, stimdur, signaldirection, block)

%Create Data Structure
Data = CreateData(subjectID, nconditions, conditions, viewdist, scrnvbl,  stimdur);

%% Define Parameters
trans = 0;
fc = [1];               %fixation cross option.  1 = present fixation at the beginning of each trial; 0 = no fixation.
fctime = 0.5;           %fixation time, in secs
leng1 = stimdur;        %stimulus duration, in secs.
leng2 = stimdur;        %not used
isi = 0.5;              %not used
iti = 0.3;              %inter-stimulus interval, in secs.

%text = '<- | ->'; %Text prompt after each trial

%% Open window and create colour shortcuts
display.dist = viewdist;    %cm
display.width = 61;       %cm
display.bkColor = [128 128 128];
colour.white = [255 255 255];
colour.black = [0 0 0];
fixcolor = [255 255 255];

% We need to determine the Screen resolution, too.

tmp = Screen('Resolution',0);
display.resolution = [tmp.width,tmp.height];
display = OpenWindow(display);

Screen(display.windowPtr, 'BlendFunction',GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
%Set font and size
Screen('TextFont',display.windowPtr,'Courier New');
Screen('TextSize',display.windowPtr,50);

%% initiate sampling for background squares -- this will stay the same the entire run

[samplehorizcolor1, samplehorizcolor2, samplevertcolor1, samplevertcolor2, blankouthoriz, blankoutvert] = ComputeBackgroundColors(display);

%Get Initial Parameters
[StimValInit, MaxtTest, InitGuess] = GetParams(stimdur);

%Initialize staircases for practice
for j = 1:nconditions
    q(j) = CreateQuest(InitGuess);
end

HideCursor;
KbWait();


%% BEGIN EXPERIMENTAL TRIALS
%Run trials
for trial=1:size(trials,1);
    
    %Extract trial parameters
    order = trials(trial,1);
    condition = trials(trial,2);
    i = condition;
    staircasenum = condition;
    
    %Check if first experimental trial -- use InitialTest value from practice trials
    if size(Data.Data.PerCondition.StimVals{i}, 1) == 0;
        tTest = log10( StimValInit );
        stimval = 10^tTest;
    else
        % Note: Instead of using QuestMedian = QuestQuantile(q(i),0.50)
        % use QuestQuantile with no parameter, which gives "most informative" value to test
                
        tTest = min(MaxtTest,QuestQuantile(q(i)));     % max tTest = 4 (since max stimval = 10000)
        stimvalmost = 10^tTest;
        stimval = 10^tTest;
    end
            
    
    %Display fixation and stimuli
    if fc(1) > 0;
        %Fixation cross
        Screen('SelectStereoDrawBuffer',display.windowPtr, 0);
        Screen('Drawline',display.windowPtr, fixcolor, display.resolution(1)/2, display.resolution(2)/2-10, display.resolution(1)/2, display.resolution(2)/2+10);  
        Screen('Drawline',display.windowPtr, fixcolor, display.resolution(1)/2-10, display.resolution(2)/2, display.resolution(1)/2+10, display.resolution(2)/2);
        %Draw Background
        DrawBackground(display, samplehorizcolor1, samplehorizcolor2, samplevertcolor1, samplevertcolor2, blankouthoriz, blankoutvert);
    
        Screen('SelectStereoDrawBuffer',display.windowPtr, 1);
        Screen('Drawline',display.windowPtr, fixcolor, display.resolution(1)/2, display.resolution(2)/2-10, display.resolution(1)/2, display.resolution(2)/2+10);  
        Screen('Drawline',display.windowPtr, fixcolor, display.resolution(1)/2-10, display.resolution(2)/2, display.resolution(1)/2+10, display.resolution(2)/2);
        %Draw Background
        DrawBackground(display, samplehorizcolor1, samplehorizcolor2, samplevertcolor1, samplevertcolor2, blankouthoriz, blankoutvert);
        
        
        Screen('flip',display.windowPtr);
        WaitSecs(fctime);
    end;

    
    %Stimuli
    signal = stimval;
    
    if order==0;                                    
        [anstime, answer]=PresentStimulus(signal, 1*signaldirection, stimdur, display, staircasenum, samplehorizcolor1, samplehorizcolor2, samplevertcolor1, samplevertcolor2, blankouthoriz, blankoutvert); %clockwise
    else                                           
        [anstime, answer]=PresentStimulus(signal, -1*signaldirection, stimdur, display, staircasenum, samplehorizcolor1, samplehorizcolor2, samplevertcolor1, samplevertcolor2, blankouthoriz, blankoutvert); %counterclockwise
    end

    Screen('SelectStereoDrawBuffer',display.windowPtr, 0);
    Screen('FillRect',display.windowPtr,display.bkColor);
    %Draw Background
    DrawBackground(display, samplehorizcolor1, samplehorizcolor2, samplevertcolor1, samplevertcolor2, blankouthoriz, blankoutvert);
    
    Screen('SelectStereoDrawBuffer',display.windowPtr, 1);
    Screen('FillRect',display.windowPtr,display.bkColor);
    %Draw Background
    DrawBackground(display, samplehorizcolor1, samplehorizcolor2, samplevertcolor1, samplevertcolor2, blankouthoriz, blankoutvert);
    
    Screen('flip',display.windowPtr);
    

    %Prompt and get response
    %disp_text(display.windowPtr,text,colour.white,display.bkColor);  %Display prompt
    %Screen('flip',display.windowPtr);
    t0=GetSecs;                                     %Start timer
    [answer, anstime]=get_key([37 39], 2, t0);          %wait for left or right arrow to be pressed
        
    %Analyze response
    [correctness] = AnalyzeResponse(order, answer);
        
    %Give feedback
    if correctness == 1
        PlayBeep(600, 0.2)
    else
        PlayBeep(100, 0.2)
    end
        
    anstime=anstime-t0;         
    
    Screen('SelectStereoDrawBuffer',display.windowPtr, 0);
    Screen('FillRect',display.windowPtr,display.bkColor);         %Clear Screen
    %Draw Background
    DrawBackground(display, samplehorizcolor1, samplehorizcolor2, samplevertcolor1, samplevertcolor2, blankouthoriz, blankoutvert);
    
    Screen('SelectStereoDrawBuffer',display.windowPtr, 1);
    Screen('FillRect',display.windowPtr,display.bkColor);         %Clear Screen
    %Draw Background
    DrawBackground(display, samplehorizcolor1, samplehorizcolor2, samplevertcolor1, samplevertcolor2, blankouthoriz, blankoutvert);
    
    Screen('flip',display.windowPtr);
    
    WaitSecs(iti);                         
        
    %Update Staircase Structure

    q(i) = QuestUpdate(q(i),tTest,correctness);
        
    %Update Data structure
	Data = UpdateData(Data, stimval, correctness, anstime, condition, order);  
end

Screen('CloseAll')
clc

%% Get thresholds and print
fprintf('\n');
for m = 1:Data.Nthresholds
    i = conditions(m);
    t = min(MaxtTest, QuestMean(q(i))); %in case at floor
    Data.Threshold(i) = 10^t;
    fprintf('Threshold Estimate = %7.3f  (%s)\n', Data.Threshold(i), char(Data.ThresholdName(i)));
    Data.ThresholdConfidenceInterval(i,1) = max(0, 10^QuestQuantile(q(i),0.025));
    Data.ThresholdConfidenceInterval(i,2) = min(10^MaxtTest, 10^QuestQuantile(q(i),0.975));
    fprintf('95%% Confidence Interval (%7.4f, %7.3f)\n', ...
        Data.ThresholdConfidenceInterval(i,1), Data.ThresholdConfidenceInterval(i,2));
end
fprintf('\n');


%% Save Data
CreateDataFile(Data)

%% Plot Data
smb{1} = '-*k';
smb{2} = '-*b';
smb{3} = '-*r';
smb{4} = '-*m';
lgdmtrx = [];

figure, hold on
for m = 1:Data.Nthresholds
    i = conditions(m);
    plot((1:size(Data.Data.PerCondition.StimVals{i},1))', Data.Data.PerCondition.StimVals{i}, smb{i});
    lgdmtrx = [lgdmtrx; Data.ThresholdName(i)];
end
legend(lgdmtrx);
xlabel('Trial');
ylabel('Signal (%)');


ShowCursor;