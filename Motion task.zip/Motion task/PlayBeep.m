function PlayBeep(w,t)

%USAGE:
%    beep
%    beep(w)    specify frequency (200-1,000 Hz)
%    beep(w,t)     "       "       and duration in seconds
%
fs=65000;  %sample freq in Hz (1000-65535 Hz)   
           % it was 8192 when using SOUND command at the end of this code

if (nargin == 0)
   w=1000;            %default
   t = [0:1/fs:.2];   %default
elseif (nargin == 1)
   t = [0:1/fs:.2];   %default
elseif (nargin == 2)
   t = [0:1/fs:t];  
end


%one possible wave form
wave=sin(2*pi*w*t);    

Snd('Play',wave,fs); 
Snd('Wait');
Snd('Quiet');
Snd('Close');